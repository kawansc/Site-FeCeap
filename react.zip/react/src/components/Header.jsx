import style from './Header.module.css';

export function Header() {
  return (
    <header className={style.header}>
      <h1>Meu primeiro site</h1>
    </header>
  );
}