import style from './Main.module.css';

export function Main() {
  return (
    <main className={style.Main}>
      <h2>Component</h2>
      <p>Component é um pequeno pedaço de interface no react</p>
    </main>
  );
}
