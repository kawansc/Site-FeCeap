import style from './Footer.module.css';

export function Footer() {
  return <footer className={style.Footer}>Este é o meu footer, desenvolvido por Kawan</footer>;
}
