import { Main } from "./components/Main";
import { Header} from "./components/Header";
import { Footer } from "./components/Footer"; 
export function App() {
  return (
    <div>
      <Main />
      <Header />
      <Footer />
    </div>
      );
}
